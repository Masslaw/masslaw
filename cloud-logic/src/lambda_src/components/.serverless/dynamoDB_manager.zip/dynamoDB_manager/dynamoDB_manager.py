import boto3

resource = boto3.resource('dynamodb')
client = boto3.client('dynamodb')


def list_tables():
    return resource.tables.all()


class DynamoDataBaseManager:
    def __init__(self, table_name):
        self.table_name = table_name
        self.table = resource.Table(table_name)

        self.primary_key = self.get_primary_key_name()

    def create_table(self, attribute_definitions, key_schema, provisioned_throughput):
        resource.create_table(
            TableName=self.table_name,
            AttributeDefinitions=attribute_definitions,
            KeySchema=key_schema,
            ProvisionedThroughput=provisioned_throughput
        )

    def delete_table(self):
        self.table.delete()

    def describe_table(self):
        return client.describe_table(TableName=self.table_name)

    def put_item(self, item, safe=False):
        if safe: item = self.get_item(item).update(item)
        self.table.put_item(Item=item)

    def get_item(self, key=None):
        response = self.table.get_item(Key=self.__ensure_key_object(key))
        item = response.get('Item') or self.get_empty_item()
        return item

    def get_items_by_attribute(self, key: dict):
        attribute_name = list(key.keys())[0]
        secondary_key_value = key[attribute_name]

        response = self.table.query(
            IndexName=f'{attribute_name}-index',
            KeyConditionExpression=f'{attribute_name} = :{attribute_name}',
            ExpressionAttributeValues={
                f':{attribute_name}': secondary_key_value
            }
        )

        return response['Count'] > 0 and response['Items'] or [None]

    def item_exists(self, key):
        return 'Item' in self.table.get_item(Key=self.__ensure_key_object(key))

    def delete_item(self, key):
        self.table.delete_item(Key=self.__ensure_key_object(key))

    def batch_write_items(self, items):
        with self.table.batch_writer() as batch:
            for item in items:
                batch.put_item(Item=item)

    def batch_delete_items(self, items):
        with self.table.batch_writer() as batch:
            for item in items:
                batch.delete_item(Key=item)

    def query(self, key_condition_expression, expression_attribute_values=None):
        if expression_attribute_values is None:
            expression_attribute_values = {}

        response = self.table.query(
            KeyConditionExpression=key_condition_expression,
            ExpressionAttributeValues=expression_attribute_values
        )

        items = response['Items']
        while 'LastEvaluatedKey' in response:
            response = self.table.query(
                KeyConditionExpression=key_condition_expression,
                ExpressionAttributeValues=expression_attribute_values,
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response['Items'])

        return items

    def scan(self, filter_expression=None, expression_attribute_values=None):
        if expression_attribute_values is None:
            expression_attribute_values = {}

        if filter_expression is None:
            response = self.table.scan()
        else:
            response = self.table.scan(
                FilterExpression=filter_expression,
                ExpressionAttributeValues=expression_attribute_values
            )

        items = response['Items']
        while 'LastEvaluatedKey' in response:
            response = self.table.scan(
                FilterExpression=filter_expression,
                ExpressionAttributeValues=expression_attribute_values,
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response['Items'])

        return items

    def batch_get_items(self, keys):
        response = self.table.batch_get_item(
            RequestItems={
                self.table_name: {
                    'Keys': [self.__ensure_key_object(k) for k in keys]
                }
            }
        )

        items = response['Responses'][self.table_name]
        while 'UnprocessedKeys' in response:
            response = self.table.batch_get_item(
                RequestItems=response['UnprocessedKeys']
            )
            items.extend(response['Responses'][self.table_name])

        return items

    def get_primary_key_name(self):
        response = self.describe_table()
        key_schema = response['Table']['KeySchema']

        for key in key_schema:
            if key['KeyType'] == 'HASH':
                return key['AttributeName']

    def update_ttl(self, ttl_attribute_name, enabled=True):
        ttl_spec = {'Enabled': enabled, 'AttributeName': ttl_attribute_name}
        self.table.update(TimeToLiveSpecification=ttl_spec)

    def get_ttl_status(self):
        return self.table.time_to_live_description

    def list_global_secondary_indexes(self):
        table_description = self.describe_table()
        return table_description.get('GlobalSecondaryIndexes', [])

    def list_local_secondary_indexes(self):
        table_description = self.describe_table()
        return table_description.get('LocalSecondaryIndexes', [])

    def get_empty_item(self):
        response = self.describe_table()
        schema = response['Table']['AttributeDefinitions']
        attribute_names = [attr['AttributeName'] for attr in schema]
        empty_item = {name: None for name in attribute_names}
        return empty_item

    def batch_get_items_from_secondary_index(self, index_name, keys):
        """
        Retrieves a batch of items from a global secondary index for the resource table.

        :param index_name: The name of the global secondary index to retrieve items from.
        :param keys: A list of keys for the items to retrieve from the index.
        :return: The list of retrieved items.
        """
        response = self.table.get_item(
            IndexName=index_name,
            Key=keys[0]
        )

        items = [response['Item']]
        for key in keys[1:]:
            response = self.table.get_item(
                IndexName=index_name,
                Key=self.__ensure_key_object(key)
            )
            items.append(response['Item'])

        return items

    def __ensure_key_object(self, key):
        return isinstance(key, dict) and key or self.__primary_key_value_to_obj(key)

    def __primary_key_value_to_obj(self, val):
        return {self.primary_key: val}

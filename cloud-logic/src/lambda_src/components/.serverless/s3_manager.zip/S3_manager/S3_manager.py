import boto3
import botocore

s3 = boto3.resource('s3')


class S3Manager:
    def __init__(self, bucket_name):
        """
        Initializes a new instance of the S3Manager class with the specified bucket name.

        :param bucket_name: The name of the S3 bucket to work with.
        """
        self.bucket_name = bucket_name
        self.bucket = s3.Bucket(bucket_name)

    def create_bucket(self, region=None):
        """
        Creates a new S3 bucket with the specified name and region.

        :param region: The AWS region to create the bucket in.
        """
        if region is not None:
            s3.create_bucket(Bucket=self.bucket_name, CreateBucketConfiguration={'LocationConstraint': region})
        else:
            s3.create_bucket(Bucket=self.bucket_name)

    def check_exists(self):
        try:
            s3.meta.client.head_bucket(Bucket=self.bucket_name)
            return True
        except botocore.exceptions.ClientError as e:
            error_code = int(e.response['Error']['Code'])
            if error_code == 403:  # private bucket
                return True
            elif error_code == 404:  # bucket does not exist
                return False

    def delete_bucket(self):
        """
        Deletes the S3 bucket.
        """
        self.bucket.delete()

    def get_bucket_location(self):
        """
        Returns the location of the S3 bucket.

        :return: The location of the bucket, or None if the bucket was not found.
        """
        try:
            response = s3.meta.client.get_bucket_location(Bucket=self.bucket_name)
            return response['LocationConstraint']
        except:
            return None

    def set_bucket_acl(self, acl):
        """
        Sets the access control list (ACL) for the S3 bucket.

        :param acl: The ACL to set for the bucket.
        """
        self.bucket.Acl().put(ACL=acl)

    def get_bucket_acl(self):
        """
        Returns the access control list (ACL) for the S3 bucket.

        :return: The ACL for the bucket, or None if the bucket was not found.
        """
        try:
            response = s3.meta.client.get_bucket_acl(Bucket=self.bucket_name)
            return response['Grants']
        except:
            return None

    def set_object_acl(self, key, acl):
        """
        Sets the access control list (ACL) for the specified object in the S3 bucket.

        :param key: The key of the object to set the ACL for.
        :param acl: The ACL to set for the object.
        """
        s3.ObjectAcl(self.bucket_name, key).put(ACL=acl)

    def get_object_acl(self, key):
        """
        Returns the access control list (ACL) for the specified object in the S3 bucket.

        :param key: The key of the object to get the ACL for.
        :return: The ACL for the object, or None if the object or bucket was not found.
        """
        try:
            response = s3.meta.client.get_object_acl(Bucket=self.bucket_name, Key=key)
            return response['Grants']
        except:
            return None

    def list_buckets(self):
        """
        Returns a list of all the S3 buckets in the current account.

        :return: A list of the names of all the buckets.
        """
        return [bucket.name for bucket in s3.buckets.all()]

    def put_object(self, key, body):
        """
        Uploads a new object to the S3 bucket.

        :param key: The key to use for the new object.
        :param body: The contents of the new object.
        """
        self.bucket.put_object(Key=key, Body=body)

    def get_object(self, key):
        """
        Retrieves an object from the S3 bucket.
        :param key: The key of the object to retrieve.
        :return: The contents of the retrieved object, or None if the object was not found.
        """
        try:
            obj = s3.Object(self.bucket_name, key).get()
            return obj['Body'].read()
        except:
            return None

    def delete_object(self, key):
        """
        Deletes an object from the S3 bucket.

        :param key: The key of the object to delete.
        """
        s3.Object(self.bucket_name, key).delete()

    def copy_object(self, source_key, destination_key):
        """
        Copies an object from one location to another in the S3 bucket.

        :param source_key: The key of the object to copy.
        :param destination_key: The key to use for the copied object.
        """
        copy_source = {
            'Bucket': self.bucket_name,
            'Key': source_key
        }
        self.bucket.copy(copy_source, destination_key)

    def list_objects(self):
        """
        Returns a list of all the objects in the S3 bucket.

        :return: A list of dictionaries containing information about the objects.
        """
        return [
            {
                'Key': obj.key,
                'Size': obj.size,
                'LastModified': obj.last_modified
            }
            for obj in self.bucket.objects.all()
        ]

    def list_objects_with_prefix(self, prefix):
        """
        Returns a list of all the objects in the S3 bucket with the specified prefix.

        :param prefix: The prefix to use for filtering the objects.
        :return: A list of dictionaries containing information about the objects.
        """
        return [
            {
                'Key': obj.key,
                'Size': obj.size,
                'LastModified': obj.last_modified
            }
            for obj in self.bucket.objects.filter(Prefix=prefix)
        ]

    def upload_file(self, local_file_path, s3_key):
        """
        Uploads a file from the local file system to the S3 bucket.

        :param local_file_path: The path to the local file to upload.
        :param s3_key: The key to use for the uploaded file in the S3 bucket.
        """
        self.bucket.upload_file(local_file_path, s3_key)

    def download_file(self, s3_key, local_file_path):
        """
        Downloads a file from the S3 bucket to the local file system.

        :param s3_key: The key of the file to download from the S3 bucket.
        :param local_file_path: The path to the local file to download to.
        """
        self.bucket.download_file(s3_key, local_file_path)

    def get_object_presigned_url(self, key, expiration=3600):
        """
        Generates a presigned URL for accessing the specified object in the S3 bucket.

        :param key: The key of the object to generate the URL for.
        :param expiration: The number of seconds until the URL expires.
        :return: The presigned URL for accessing the object.
        """
        return s3.meta.client.generate_presigned_url(
            'get_object',
            Params={'Bucket': self.bucket_name, 'Key': key},
            ExpiresIn=expiration
        )

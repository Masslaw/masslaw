import json
import os

from masslaw_users import masslaw_users
from networking import networking_consts
from util import json_utils


def handler(event, context):

    event = json_utils.ensure_json(event)

    target_user_id = json_utils.get_from(event, [networking_consts.EventKeys.QUERY_STRING_PARAMETERS, 'user_id'])
    target_user_id = (target_user_id and len(target_user_id) > 0) and target_user_id or None

    access_token = json_utils.get_from(event, [networking_consts.EventKeys.HEADER_PARAMETERS, 'access_token'])
    userStatus = masslaw_users.MasslawUsersManager.get_user_status(access_token)

    userData = get_user_data(target_user_id, access_token, userStatus)
    if not userData:
        return {
            networking_consts.EventKeys.STATUS_CODE: networking_consts.StatusCodes.BAD_REQUEST,
            networking_consts.EventKeys.HEADER_PARAMETERS: {},
            networking_consts.EventKeys.BODY: json.dumps({
                networking_consts.EventKeys.RESPONSE_MESSAGE: networking_consts.ResponseMessages.BAD_REQUEST,
                'user_data': {},
            }),
            networking_consts.EventKeys.USER_STATUS: userStatus
        }

    return {
        networking_consts.EventKeys.STATUS_CODE: networking_consts.StatusCodes.OK,
        networking_consts.EventKeys.HEADER_PARAMETERS: {},
        networking_consts.EventKeys.BODY: json.dumps({
            networking_consts.EventKeys.RESPONSE_MESSAGE: networking_consts.ResponseMessages.OPERATION_EXECUTED_SUCCESSFULLY,
            'user_data': userData,
        }),
        networking_consts.EventKeys.USER_STATUS: userStatus
    }


def get_user_data(target_user_id, access_token, userStatus):
    myData = None
    if access_token and (userStatus > masslaw_users.UserStatuses.GUEST):
        myData = get_my_data(access_token)

    if target_user_id:
        if target_user_id != (myData or {}).get("user_id"):
            return get_others_data(target_user_id)

    if myData:
        return myData

    return None


def get_my_data(access_token):
    return masslaw_users.MasslawUsersManager.get_data_by_auth(access_token, masslaw_users.AccessActions.READ, masslaw_users.PermissionEntities.USER_CLIENT)


def get_others_data(userId):
    return masslaw_users.MasslawUsersManager.get_data_by_id(userId, masslaw_users.AccessActions.READ, masslaw_users.PermissionEntities.USER_OTHER_CLIENT)


if __name__ == "__main__":
    print(handler({
        networking_consts.EventKeys.QUERY_STRING_PARAMETERS: {
            'user_id': '184f2fad-14a6-4b23-83f3-2a02c1d2b34d'
        },
        networking_consts.EventKeys.HEADER_PARAMETERS: {
            'access_token': "eyJraWQiOiIrMUdsYTB4QzlqR2czaDl5VmVsVThGNEw3bzBpNFIxTkQ3bW11UFlXYm4wPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI4M2ZlMGEwOC1mZTQwLTQ1Y2MtOGU5OS00Mjc2Yjc1NTI0M2EiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV8wZVVLeHlnUVoiLCJjbGllbnRfaWQiOiI3YTJpcmpiM2k3bzN2Z281c2Y5dDluYWQ2MiIsIm9yaWdpbl9qdGkiOiJiNTMyMGZlZS0wNDhjLTQ3MGMtYmIxYi02MzZiNjE4MjBlMmUiLCJldmVudF9pZCI6ImRmOGYxZGNkLTJjOGItNGFmNi1hMGU2LTYxYjc1ZjZhNmY2NiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYXdzLmNvZ25pdG8uc2lnbmluLnVzZXIuYWRtaW4iLCJhdXRoX3RpbWUiOjE2Nzk1MTkyNTksImV4cCI6MTY3OTUyMjg1OSwiaWF0IjoxNjc5NTE5MjU5LCJqdGkiOiI2OWE2MzE2My0xZDlmLTQxOTYtOTVkNi1mZGMyMTI5MDA5ZjYiLCJ1c2VybmFtZSI6IjgzZmUwYTA4LWZlNDAtNDVjYy04ZTk5LTQyNzZiNzU1MjQzYSJ9.NlvkzgWMC1ZZ8AXoJilIkwbvJQxtA5nd2V9GQxfQyOHSRnPOlPQja3Yaz-xdFZ3VGEMRC984HuJA_AWeU3D97CRm9XeQ1boTcebd2uS39usJFHAZ60gmSIfnE64OBfSFQB8CFvJ4niYgvflcQ-EeOqucCXa3C7A8x-l-zCJaYxykihAfW5ptAwCMMsnIfmlxonSlGqKrV83GA_7zlMTPVvrFIDTzOYAOluMtZ4wFUPaTTCePnKUTei_A-rmmT7CXqoGslop6ZBvUQ0VJu5lwBs178l0A4E3jYsP6IBm-iApwJwkbGm2kgoXxnLSW2sy7dSY3b48YM-netJ7Il1-NFg"
        }
    }, None))
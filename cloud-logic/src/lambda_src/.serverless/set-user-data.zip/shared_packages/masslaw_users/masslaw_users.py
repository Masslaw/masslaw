import os

from cognito_manager import cognito_manager
from util import json_utils

cognitoManager = cognito_manager.CognitoManager("MasslawUsers")


class UserStatuses:
    UNKNOWN = -1
    GUEST = 0
    LOGGED_IN = 10
    MISSING_CREDENTIALS = 20
    FULL_ACCESS = 100


class UserKeys:
    USER_ID = 'user_id'
    EMAIL = 'email'
    FIRST_NAME = 'first_name'
    LAST_NAME = 'last_name'
    PHONE = 'phone'
    CASES = 'cases'
    S3_BUCKET = 's3_bucket'
    EXTRA_DATA = 'extra_data'

    ALL = [
        USER_ID,
        FIRST_NAME,
        LAST_NAME,
        EMAIL,
        PHONE,
        CASES,
        S3_BUCKET,
        EXTRA_DATA,
    ]


class PermissionEntities:
    SERVER = "server"
    USER_CLIENT = "user_client"
    USER_OTHER_CLIENT = "user_other_client"


class AccessActions:
    EDIT = "edit"
    READ = "read"


PERMISSION_KEY_GROUPS = {
    AccessActions.EDIT: {
        PermissionEntities.SERVER: [
            UserKeys.FIRST_NAME,
            UserKeys.LAST_NAME,
            UserKeys.PHONE,
            UserKeys.CASES,
            UserKeys.EXTRA_DATA,
        ],
        PermissionEntities.USER_CLIENT: [
            UserKeys.FIRST_NAME,
            UserKeys.LAST_NAME,
            UserKeys.PHONE,
        ],
        PermissionEntities.USER_OTHER_CLIENT: []
    },
    AccessActions.READ: {
        PermissionEntities.SERVER: UserKeys.ALL,
        PermissionEntities.USER_CLIENT: [
            UserKeys.USER_ID,
            UserKeys.FIRST_NAME,
            UserKeys.LAST_NAME,
            UserKeys.EMAIL,
            UserKeys.PHONE,
            UserKeys.CASES,
        ],
        PermissionEntities.USER_OTHER_CLIENT: [
            UserKeys.USER_ID,
            UserKeys.FIRST_NAME,
            UserKeys.LAST_NAME,
            UserKeys.EMAIL,
            UserKeys.PHONE,
            UserKeys.CASES,
        ]
    }
}

UNIQUE_PROPERTIES = [
    UserKeys.EMAIL,
    UserKeys.PHONE,
]


class LoginMethods:
    EMAIL = "email",
    PHONE = "phone",
    GOOGLE = "google",


class MasslawUsersManager:
    @staticmethod
    def get_user_status(access_token) -> int:
        user = cognitoManager.get_user_by_access_token(access_token)

        if not user: return UserStatuses.GUEST

        if not MasslawUsersManager.__validate_user_data(user): return UserStatuses.MISSING_CREDENTIALS

        return UserStatuses.LOGGED_IN

    @staticmethod
    def __validate_user_data(userData):
        return ((fName := userData.get(UserKeys.FIRST_NAME)) and
                isinstance(fName, str) and
                len(fName) > 2 and
                (lName := userData.get(UserKeys.LAST_NAME)) and
                isinstance(lName, str) and
                len(lName) > 2)

    @staticmethod
    def get_data_by_id(userId, forAction, asEntity):
        userData = cognitoManager.get_user_by_id(userId)
        return MasslawUsersManager.__format_data_for_access(userData, forAction, asEntity)

    @staticmethod
    def get_data_by_auth(token, forAction, asEntity):
        userData = cognitoManager.get_user_by_access_token(token)
        return MasslawUsersManager.__format_data_for_access(userData, forAction, asEntity)

    @staticmethod
    def get_data_by_email(email, forAction, asEntity):
        userData = cognitoManager.get_user_by_id(email)
        return MasslawUsersManager.__format_data_for_access(userData, forAction, asEntity)

    @staticmethod
    def __format_data_for_access(userData, forAction, asEntity):
        return json_utils.select_keys(userData, json_utils.get_from(PERMISSION_KEY_GROUPS, [forAction, asEntity]))


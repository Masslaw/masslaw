import json
from typing import Union


def ensure_json(d: Union[dict, str]):
    d = isinstance(d, dict) and d or \
          isinstance(d, str) and try_loads(str(d)) or \
          d
    if isinstance(d, dict):
        for key in list(d.keys()):
            d[key] = ensure_json(d[key])
    return d


def try_loads(d: str):
    try: return json.loads(d)
    except: return None


def get_from(d: dict, path: list[str]):
    for key in path:
        if not isinstance(d, dict): return None
        if key not in d: return None
        d = d[key]
    return d


def set_at(d: dict, path: list[str], element):
    curr_d = d
    for key in path[:-1]:
        if not isinstance(curr_d, dict): return d
        if key not in curr_d: curr_d[key] = {}
        curr_d = curr_d[key]
    curr_d[path[-1]] = element
    return d


def select_keys(d: dict, keys):
    return (d and isinstance(d, dict)) and {k: v for k, v in d.items() if k in keys} or {}

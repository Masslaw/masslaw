import boto3
from botocore.exceptions import ClientError

client = boto3.client('cognito-idp')


class CognitoManager:
    def __init__(self, user_pool_name):
        self.user_pool_name = user_pool_name
        self.user_pool_id = self.get_user_pool_id()

    def get_user_pool_id(self):
        response = client.list_user_pools(MaxResults=60)
        user_pools = response['UserPools']
        for user_pool in user_pools:
            if user_pool['Name'] == self.user_pool_name:
                return user_pool['Id']
        raise ValueError(f'User pool {self.user_pool_name} not found')

    def create_user(self, email, password):
        response = client.sign_up(
            ClientId=self.user_pool_id,
            Username=email,
            Password=password,
            UserAttributes=[
                {
                    'Name': 'email',
                    'Value': email
                },
            ]
        )
        return response

    def get_user_by_access_token(self, access_token):
        try:
            response = client.get_user(
                AccessToken=access_token,
            )
            user_data = CognitoManager.__parse_get_user_response(response)
            return user_data
        except ClientError as e:
            return None

    def get_user_by_id(self, userName):
        try:
            response = client.admin_get_user(
                Username=userName,
                UserPoolId=self.user_pool_id,
            )
            user_data = CognitoManager.__parse_get_user_response(response)
            return user_data
        except ClientError as e:
            return None

    def get_user_by_email(self, email):
        response = client.list_users(
            UserPoolId=self.user_pool_id,
            Filter=f"email = \"{email}\""
        )
        if len(response['Users']) == 0:
            raise ValueError(f"User with email {email} not found")
        user_data = CognitoManager.__parse_get_user_response(response['Users'][0])
        return user_data

    def update_user_properties(self, user_id, to_update):
        response = client.admin_update_user_attributes(
            UserPoolId=self.user_pool_id,
            Username=user_id,
            UserAttributes=[to_update],
        )
        return response['ResponseMetadata']['HTTPStatusCode'] == 200

    def confirm_user(self, email, confirmation_code):
        response = client.confirm_sign_up(
            ClientId=self.user_pool_id,
            Username=email,
            ConfirmationCode=confirmation_code
        )
        return response

    def delete_user(self, email):
        response = client.admin_delete_user(
            UserPoolId=self.user_pool_id,
            Username=email
        )
        return response

    def list_users(self):
        response = client.list_users(
            UserPoolId=self.user_pool_id,
            AttributesToGet=[
                'email'
            ]
        )
        users = [user['Attributes'][0]['Value'] for user in response['Users']]
        return users

    @staticmethod
    def __parse_get_user_response(response):
        user_data = {}
        user_data['user_id'] = response['Username']
        for d in response['UserAttributes']:
            user_data[d['Name']] = d['Value']
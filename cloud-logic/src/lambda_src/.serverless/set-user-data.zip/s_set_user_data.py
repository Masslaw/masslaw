import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='shinyshimi',
    application_name='masslaw',
    app_uid='10dky5JxdgLq5td5V9',
    org_uid='66684a3d-0bf6-480a-bbbb-1a74700b42da',
    deployment_uid='8dc842da-b837-4586-908e-97366b4a90bd',
    service_name='masslaw',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='prod',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'masslaw-prod-set-user-data', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('set_user_data.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)

import json
import os


from masslaw_users import masslaw_users
from networking import networking_consts
from util import json_utils


def handler(event, context):

    event = json_utils.ensure_json(event)

    access_token = json_utils.get_from(event, [networking_consts.EventKeys.HEADER_PARAMETERS, 'access_token'])
    userStatus = masslaw_users.MasslawUsersManager.get_user_status(access_token)

    if userStatus < masslaw_users.UserStatuses.GUEST:
        return {
            networking_consts.EventKeys.STATUS_CODE: networking_consts.StatusCodes.BAD_REQUEST,
            networking_consts.EventKeys.HEADER_PARAMETERS: {},
            networking_consts.EventKeys.BODY: json.dumps({
                networking_consts.EventKeys.RESPONSE_MESSAGE: networking_consts.ResponseMessages.BAD_REQUEST,
            }),
            networking_consts.EventKeys.USER_STATUS: userStatus
        }

    newData = json_utils.get_from(event, [networking_consts.EventKeys.PAYLOAD, 'user_data'])

    return {
        networking_consts.EventKeys.STATUS_CODE: networking_consts.StatusCodes.OK,
        networking_consts.EventKeys.HEADER_PARAMETERS: {},
        networking_consts.EventKeys.BODY: json.dumps({
            networking_consts.EventKeys.RESPONSE_MESSAGE: networking_consts.ResponseMessages.OPERATION_EXECUTED_SUCCESSFULLY,
        }),
        networking_consts.EventKeys.USER_STATUS: userStatus
    }

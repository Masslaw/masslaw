GLOBAL_VALUES_DYNAMODB_TABLE_NAME = "MasslawCloudConfigurations"

### keys
SUPPORTED_MLCP_FILE_TYPES = "supported_mlcp_file_types"
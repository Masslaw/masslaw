READ_ONLY_USER_ATTRIBUTES = [
    'email',
    'email_verified'
]
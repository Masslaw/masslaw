FILE_DESCRIPTION_LENGTH_HARD_LIMIT = 500  # file descriptions can have a maximum length of 500 characters

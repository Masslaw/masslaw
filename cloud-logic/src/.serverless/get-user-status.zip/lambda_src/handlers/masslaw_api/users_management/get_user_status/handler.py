from lambda_src.components.masslaw_users.lambda_templates.authenticated_masslaw_user_http_invoked_lambda_function import *


class GetUserStatus(AuthenticatedMasslawUserHttpInvokedLambdaFunction):
    pass


handler = GetUserStatus()

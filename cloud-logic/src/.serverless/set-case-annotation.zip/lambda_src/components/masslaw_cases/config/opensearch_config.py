MASSLAW_CASES_ES_ENDPOINT = 'https://search-masslaw-cases-yi2q4reazwjmc3zxq7qrz67qrq.us-east-1.es.amazonaws.com'
MASSLAW_CASE_FILES_SEARCH_INDEX_SUFFIX = '-case-files-search-index'
MASSLAW_CASE_ANNOTATIONS_SEARCH_INDEX_SUFFIX = '-case-annotations-search-index'
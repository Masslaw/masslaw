USER_OWN_CLIENT_KEYS = [
    'User_ID',
    'first_name',
    'last_name',
    'email',
    'phone',
    'client_extra_data',
]

USER_OTHER_CLIENT_KEYS = [
    'User_ID',
    'first_name',
    'last_name',
    'email',
    'phone',
]

CLIENT_WRITE_KEYS = [
    'first_name',
    'last_name',
    'phone',
]
